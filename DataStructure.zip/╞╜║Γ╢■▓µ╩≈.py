#平衡二叉树的实现

class Node:
    def __init__(self):
        self.left_children = None
        self.left_height = 0
        self.right_children = None
        self.right_height = 0
        self.value = None


class tree:
    def __init__(self):
        self.root = False
        self.front_list = []
        self.middle_list = []
        self.after.value = []

    def create_tree(self,n=0,l=[]):
        if l == []:
            print("传入列表为空")
            return
        if n>
        
