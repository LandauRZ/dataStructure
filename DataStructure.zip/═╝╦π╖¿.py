#顶点表节点：

class VertexNode(object):
    def __init__(self, vertexname, visited = False, p = None):
        self.vertexName = vertexname
        self.Visited = visited
        self.firstNode = p       #指向边表节点的指针

#边表节点：

class EdgeNode(object):
    def __init__(self, index, weight, p = None):
        self.Index = index
        self.Weight = weight
        self.Next = p      #链接同一顶点表节点的下一条边

#邻接表存储图结构：

class Adgraph(object):

    def __init__(self, vcount=0):
        self.vertexList = []
        self.vertexCount = vcount

    def initList(self, data:list):
        for i in data:
            A = VertexNode(i)
            self.vertexList.append(A)
        self.vertexCount = len(data)

    def GetIndex(self, data):
        for i in range(self.vertexCount):
            temp = self.vertexList[i].vertexName
            if (temp != None) and (data == temp):
                return i

            return -1

    def AddEgde(self, startNode, endNode, weight):
        i = self.GetIndex(startNode)
        j = self.GetIndex(endNode)
        if i == -1 or j == -1:
            print("该边不存在")
        else:
            weight = float(weight)
            temp = self.vertexList[i].firstNode
            if temp == None:
                self.vertexList[i].firstNode = EdgeNode(j, weight)
            else:
                while(temp.Next != None):
                    temp = temp.Next
                temp.Next = EdgeNode(j, weight)



# 深度优先遍历（DFS）————栈（BFS使用队列）

    def DFS(self, i):
        self.vertexList[i].Visited = True
        res = self.vertexList[i].vertexName+'\n'
        p = self.vertexList[i].firstNode
        while(p!=None):
            if self.vertexList[p.Index].Visited == True:
                p = p.Next
            else:
                res += self.DFS(p.Index)
        return res


#深度优先入口
    def DFStravel(self, start):
        i = self.GetIndex(start)
        if i != -1:
            for j in range(self.vertexCount):
                self.vertexList[j].Visited = False
            DFSres = self.DFS(i)

        return DFSres


'''
深度优先搜索用栈（stack）来实现，整个过程可以想象成一个倒立的树形：
1、把根节点压入栈中。
2、每次从栈中弹出一个元素，搜索所有在它下一级的元素，把这些元素压入栈中。并把这个元素记为它下一级元素的前驱。
3、找到所要找的元素时结束程序。
4、如果遍历整个树还没有找到，结束程序。
'''


