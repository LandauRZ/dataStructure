'''
红黑树是每个节点都带有颜色属性的二叉查找树，颜色为红色或者黑色
在二叉查找树强制一般要求以外，对任何有效的红黑树我增加了如下的
额外要求：
1，节点是红色或者黑色
2，根是黑色
3，所有叶子都是黑色
4，每个红色节点必须有两个黑色的子节点
5，从任何节点到其每个叶子的所有简单路径都包含相同数目的黑色节点
'''
from eum import Enum

class ColorEnum(Enum):
    RED = "red"
    BLACK = "black"

class RBTreeNode:
    def __init__(self):
        self.val = None
        self.lchildren = None
        self.rchildren = None
        self.parent = None
        self.color = None
    
class RBTree
    def __init__(self):
        self.root = None
#左旋
    def left_rotate(self, x:RBTreeNode):
        y = x.rchildren
        y.parent = x.parent
        x.rchildren = y.lchildren
        y.lchildren.parent = x
        if not x.parent:
            x.parent = y
        elif x.parent.lchildren == x:
            x.parent.lchildren = y
        else:
            x.parent.rchildren = y
#右旋
    def right_rotate(self, x:RBTreeNode):
        y = x.lchildren
        y.parent = x.parent
        y.rchildren.parent = x
        x.lchildren = y.rchildren
        if not x.parent:
            x.parent = y
        elif x.parent.lchildren = x:
            x.parent.lchildren = y
        else:
            x.parent.rchildren = y
#插入
    def rb_insert(self, z:RBTreeNode):
        x = self.root
        y = None
        while x:
            y = x
            if z.val < x.val:
                x = x.lchildren
            else:
                x = x.rchildren
        z.parent = y
        if y == None:
            self.root = z
        elif z.val > y.val:
            y.rchildren = z
        else:
            y.lchildren = z
        
        z.lchildren = None
        z.rchildren = None
        z.color = ColorEnum.RED
        self.rb_insert_fixup(z)
#插入调整
    def rb_insert_fixup(self, z:RBTreeNode):
        while z.parent.color == ColorEnum.RED:
            if z.parent == z.parent.parent.lchildren:
                y = z.parent.parent.rchildren
                if y.color == ColorEnum.RED:
                    z.parent.color = ColorEnum.BLACK
                    y.color = ColorEnum.BLACK
                    z.parent.parent.color = ColorEnum.RED
                    z = z.parent.parent
                elif y.color == ColorEnum.BLACK and z == z.parent.rchildren:
                    z = z.parent
                    self.left_rotate(z)
                else:
                    z.parent.color = ColorEnum.BLACK
                    z.parent.parent.color = ColorEnum.RED
                    self.right_rotate(z)
            else:
                y = z.parent.parent.lchildren
                if y.color == ColorEnum.RED:
                    z.parent.color = ColorEnum.BLACK
                    y.color = ColorEnum.BLACK
                    z.parent.parent.color = ColorEnum.RED
                    z = z.parent.parent
                elif y.color == ColorEnum.BLACK and z == z.parenet.lchildren:
                    z = z.parent
                    self.right_rotate(z)
                else:
                    z.parent.color = ColorEnum.BLACK
                    z.parent.parent.color = ColorEnum.RED
                    self.left_rotate(z)

    

                    





