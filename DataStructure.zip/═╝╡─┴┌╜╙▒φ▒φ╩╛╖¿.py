#邻接表表示法

class Graph:

    def __init__(self, gdict=None):
        if gdict is None:
            gdict = {}
        self.gdict = gdict

    def edges(self):
        return self.findedges()

    def AddEdge(self, edge):
        edge = set(edge)
        (vrtx1, vrtx2) = tuple(edge)
        if vrtx1 in self.gdict:
            self.gdict[vrtx1].append(vrtx2)
        else:
            self.gdict[vrtx1] = [vrtx2]

    def findedges(self):
        edgename = []
        for vrtx in self.gdict:
            for nxtvrtx in self.gdict[vrtx]:
                if {nxtvrtx, vrtx} not in edgename:
                    edgename.append({vrtx, nxtvrtx})
        return edgename


graph_elements = { "a": ["b", "c"],
                   "b": ["a", "d"],
                   "c": ["a", "d"],
                   "d": ["e"],
                   "e": ["d"]
                }

g = Graph(graph_elements)
g.AddEdge({'a', 'c'})
g.AddEdge({'a', 'e'})
print(g.edges())


