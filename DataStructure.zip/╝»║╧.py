Days= set(["Mon", "Tue", "Wed", "Thu", "Fri"])
Days.add("Sun")
Days.discard("Mon")

#交集
Days_prime = set(["Saturday", "Fri"])

Alldays = Days & Days_prime
#并集
Alldays_2 = Days | Days_prime
#差集
Alldays_3 = Days - Days_prime


print(Days)