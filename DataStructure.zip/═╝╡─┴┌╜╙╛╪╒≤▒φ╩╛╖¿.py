#python中的矩阵我们用两个列表表示

class Graph(object):

    def __init__(self):

        self._count = int(input("Please input the number of the vertex in the graph: "))
        self._adjlist = [[None for i in range(self._count)] for i in range(self._count)]
        self._peaklist = []

        for i in range(self._count):
            self._peaklist.append(input('input the vertex: '))
    
    def add_relationship(self):

        print("Please input the relationship among these vertex: ")

        for i in range(self._count):
            self._adjlist[i][i] = 0
            for j in range(self._count):
                while self._adjlist = None:
                    msg = input("input the relationship between dot %s and %s (1 is connect, 0 is not)" % (self._peaklist[i], self.peaklist[j]))
                    if msg == '0' or msg == '1':
                        self._adjlist[i][j] = int(msg)
                        self._adjlist[j][i] = self._adjlist[i][j]
                    else:
                        print("error!")
                    
        
        for i in range(self._count):
            print(self._adjlist[i])


if __name__ == '__main__':
    s = Graph
    s.add_relationship()
