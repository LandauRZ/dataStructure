import collections

DoubleEnded = collections.deque(["Mon", "Tue", "Wed"])
print(DoubleEnded)

print("Adding to the  right: ")
DoubleEnded.append("Thu")
print(DoubleEnded)

print("Adding to the left: ")
DoubleEnded.appendleft("Sun")

print("Removing from the right: ")
DoubleEnded.pop()
print(DoubleEnded)

print("Removing from the left: ")
DoubleEnded.popleft()
print(DoubleEnded)

print("Reversing the deque: ")
DoubleEnded.reverse()
print(DoubleEnded)
